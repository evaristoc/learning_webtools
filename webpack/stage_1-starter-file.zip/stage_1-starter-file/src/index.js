
import {one, two, three} from '../js/func_list.js'

one()

two()

//three()


require('../css/main.css')