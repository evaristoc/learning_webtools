var p = document.createElement('p')
p.innerText = 'THIRD.js by NATIVE JS'
p.setAttribute('id','THIRD')
document.body.appendChild(p)