var p = document.createElement('p')
p.innerText = 'SECOND.js by NATIVE JS'
p.setAttribute('id','second')
document.body.appendChild(p)