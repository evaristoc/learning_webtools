var p = document.createElement('p')
p.innerText = 'FIRST.js by NATIVE JS'
p.setAttribute('id','first')
document.body.appendChild(p)